// ======= All rights maybe not reserved totally. ==========
//
// lua\RBPSentity.lua
//
//    Created by:   Synomi and Zups and UWE
//
// ========= For more information, visit us at ns2stats.com or #ns2stats @ qnet =====================

class 'RoundBasedPlayerStats' (Entity)

RoundBasedPlayerStats.kMapName = "RBPS"

function RoundBasedPlayerStats:OnCreate()

end

function RoundBasedPlayerStats:OnDestroy()

end