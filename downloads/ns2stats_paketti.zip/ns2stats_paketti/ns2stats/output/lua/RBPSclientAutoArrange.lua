// ======= All rights maybe not reserved totally. ==========
//
// lua\RBPSclientAutoArrange.lua
//
//    Created by:   Synomi
//
// ========= For more information, visit us at ns2stats.com or #ns2stats @ qnet =====================

